<aside class="sidebar">
    <nav>
        <ul>
            <li><a href="/index.php">Kezdőlap</a></li>
            <li><a href="/modules/profile/index.php">Felhasználók Kezelése</a></li>
            <!-- További admin menüpontok itt -->
        </ul>
    </nav>
</aside>
