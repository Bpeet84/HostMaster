<footer>
    &copy; 2024 HostMaster Admin. Minden jog fenntartva.
</footer>
