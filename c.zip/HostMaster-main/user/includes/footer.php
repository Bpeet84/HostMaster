<footer>
    &copy; 2024 HostMaster. Minden jog fenntartva.
</footer>
